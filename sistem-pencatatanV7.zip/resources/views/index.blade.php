@extends('master')
@section('title', 'Dashboard')
@section('content')
@endsection
