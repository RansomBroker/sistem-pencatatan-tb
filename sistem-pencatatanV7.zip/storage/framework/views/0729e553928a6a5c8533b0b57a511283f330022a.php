<?php $__env->startSection('title', 'Tambah Advance Receive Baru'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        
        <div class="mb-3">
            <h2 class="h2 d-inline align-middle fw-bold">Tambah Advance Receive Baru</h2>
        </div>

        
        <div class="card card-body">
            <form method="POST" action="<?php echo e(URL::to('advance-receive/advance-receive-add/add')); ?>">
                
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="mb-3 col-12 col-lg-12">
                        <label class="form-label">Cabang penjualan <sup class="text-danger">(Required)</sup></label>
                        <select class="form-select <?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="branch" >
                            <?php if(old('branch') == null): ?>
                                <option value="" selected>---- Select branch ----</option>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branch->id); ?>" <?php if(old('branch') == $branch->id): ?> selected <?php endif; ?>><?php echo e($branch->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12">
                        <label class="form-label">Tanggal Penjualan <sup class="text-danger">(Required)</sup></label>
                        <input type="date" data-type="buy-date" class="form-control <?php $__errorArgs = ['buy-date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="buy-date" value="<?php echo e(old('buy-date')); ?>"/>
                        <?php $__errorArgs = ['buy-date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12">
                        <label class="form-label">Expired Date <sup class="text-danger">(Required)</sup></label>
                        <input type="date" data-target="expired-date" class="form-control <?php $__errorArgs = ['expired-date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="expired-date" value="<?php echo e(old('expired-date')); ?>"/>
                        <?php $__errorArgs = ['expired-date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12">
                        <label class="form-label">ID Customer <sup class="text-danger">(Required)</sup></label>
                        <input type="text" data-type="customer-id" class="form-control <?php $__errorArgs = ['customer-id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="customer-id" value="<?php echo e(old('customer-id')); ?>" placeholder="Ketikan ID Customer"/>
                        <?php $__errorArgs = ['customer-id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 d-flex flex-column">
                        <label class="form-label">Nama Customer</label>
                        <input type="text" data-type="customer-name" class="form-control <?php $__errorArgs = ['customer-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="customer-name" value="<?php echo e(old('customer-name')); ?>" readonly/>
                        <div class="spinner-border text-primary d-none" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <?php $__errorArgs = ['customer-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12">
                        <label class="form-label">Tipe <sup class="text-danger">(Required)</sup></label>
                        <select class="form-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="type" >
                            <option value="" selected>--- tipe customer ---</option>
                            <option value="NEW">New</option>
                            <option value="REPEATER">Repeater</option>
                        </select>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 d-flex flex-column">
                        <label class="form-label">IDR Harga Beli <sup class="text-danger">(Required)</sup></label>
                        <input type="text" data-type="currency" class="form-control <?php $__errorArgs = ['buy-price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="buy-price" value="<?php echo e(old('buy-price')); ?>"/>
                        <?php $__errorArgs = ['buy-price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12">
                        <label class="d-block form-label">Include PPN </label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input <?php $__errorArgs = ['tax-include'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio" name="tax-include" value="1" checked/>
                            <label class="form-check-label">ya</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input <?php $__errorArgs = ['tax-include'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio" name="tax-include" value="0"/>
                            <label class="form-check-label">tidak</label>
                        </div>
                        <?php $__errorArgs = ['tax-include'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 d-flex flex-column">
                        <label class="form-label">IDR Net Sales <sup class="text-danger">(Otomatis)</sup></label>
                        <input type="text" data-type="net-sales" class="form-control <?php $__errorArgs = ['net-sales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="net-sales" value="<?php echo e(old('net-sales')); ?>" readonly/>
                        <?php $__errorArgs = ['net-sales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 d-flex flex-column">
                        <label class="form-label">IDR PPN <sup class="text-danger">(Otomatis)</sup></label>
                        <input type="text" data-type="tax" class="form-control <?php $__errorArgs = ['tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tax" value="<?php echo e(old('tax')); ?>" readonly/>
                        <?php $__errorArgs = ['tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 d-flex flex-column">
                        <label class="form-label">Pembayaran <sup class="text-danger">(Required)</sup></label>
                        <input type="text" class="form-control <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="payment" value="<?php echo e(old('payment')); ?>" />
                        <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 d-flex flex-column">
                        <label class="form-label">QTY Produk <sup class="text-danger">(Required)</sup></label>
                        <input type="number" data-type="qty" class="form-control <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qty" value="<?php echo e(old('qty')); ?>" />
                        <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 d-flex flex-column">
                        <label class="form-label">IDR Harga Satuan <sup class="text-danger">(Otomatis)</sup></label>
                        <input type="text" data-type="unit-price" class="form-control <?php $__errorArgs = ['unit-price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="unit-price" value="<?php echo e(old('unit-price')); ?>" readonly/>
                        <?php $__errorArgs = ['unit-price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12">
                        <label class="form-label">Produk <sup class="text-danger">(Required)</sup></label>
                        <select class="form-select <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-type="product-select" name="product" >
                            <?php if(old('product') == null): ?>
                                <option value="0" selected>---- Select Product ----</option>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>" <?php if(old('product') == $product->id): ?> selected <?php endif; ?>><?php echo e($product->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 d-flex flex-column">
                        <label class="form-label">Kategori Paket <sup class="text-danger">(Otomatis)</sup></label>
                        <input type="text" data-target="category" class="form-control <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="category" value="<?php echo e(old('category')); ?>" readonly/>
                        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 d-flex flex-column">
                        <label class="form-label">Notes<sup class="text-danger">(Optional)</sup></label>
                        <input type="text" data-type="notes" class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="notes" value="<?php echo e(old('notes')); ?>"/>
                        <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-secondary col-12 col-lg-12 mb-3">Tambah Advance Receive Baru</button>
                    <button type="reset" class="btn btn-danger col-12 col-lg-12"> reset</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script>
        $("input[data-type=buy-date]").change(function() {
            let expiredDate = new Date($(this).val())
            expiredDate.setFullYear(expiredDate.getFullYear() + 2);
            let expiredDateFormat = expiredDate.toISOString().split('T')[0]
            $("input[data-target=expired-date]").val(expiredDateFormat);
        });

        $("input[data-type=customer-id]").on('keyup', function () {
            $("input[data-type=customer-name]").addClass('d-none')
            $('.spinner-border').removeClass('d-none')
            fetch('<?php echo e(URL::to('customer-get')); ?>'+ '/' + $(this).val(), {
                method: "GET"
            })
            .then(response => response.json())
            .then(result => {
                console.log(result)
                if (result.data === null) {
                    $("input[data-type=customer-name]").removeClass('d-none')
                    $('.spinner-border').addClass('d-none')
                    $("input[data-type=customer-name]").attr('placeholder', 'data tidak ditemukan (pastikan customer telah terdapat pada master data)')
                    $("input[data-type=customer-name]").attr('value', '')
                }
                $("input[data-type=customer-name]").removeClass('d-none')
                $('.spinner-border').addClass('d-none')
                $("input[data-type=customer-name]").attr('value', result.data.name)
            })
        })

        $("input[data-type=customer-id]").focusout(function () {
            $("input[data-type=customer-name]").removeClass('d-none')
            $('.spinner-border').addClass('d-none')
        })

        $("select[data-type=product-select]").change(function () {
            let data = $(this).val();

            fetch("<?php echo e(URL::to('category-get')); ?>" + '/' + data, {
                method: "GET"
            })
            .then(response => response.json())
            .then(result => {
                if (result.data === null) {
                    $("input[data-target=category]").attr("placeholder", "Kategori Tidak Ditemukan")
                    $("input[data-target=category]").attr("value", '')
                }
                $("input[data-target=category]").attr("value", result.data.categories[0].name)
            })
            .catch(e => {
                console.log(e)
            })
        })

        $("input[name=buy-price]").on('keyup', function () {
            // get real number
            const regex = /[,]/g;
            let buyPrice = $(this).val();
            let qty = $("input[data-type=qty]").val() || 0;
            let price = buyPrice.replace(regex, '');
            let isTaxInclude = $("input[name=tax-include]").val()
            let netSale = 0;
            let tax = 0;
            let unitPrice = 0;
            /* if radio button was selected first*/
            if (isTaxInclude == 1) {
                netSale = Math.round(price/1.11);
                tax = Math.floor(price-netSale);
                unitPrice = Math.round(netSale/qty) || 0;
                /* set to input value placeholder */
                $("input[data-type=net-sales]").val(formatCurrencyPrice(netSale))
                $("input[data-type=tax]").val(formatCurrencyPrice(tax))
                $("input[data-type=unit-price]").val(formatCurrencyPrice(unitPrice))
            } else {
                netSale = parseInt(price);
                unitPrice = parseInt(netSale/qty) || 0;
                /* set to input value placeholder */
                $("input[data-type=net-sales]").val(formatCurrencyPrice(netSale))
                $("input[data-type=tax]").val(formatCurrencyPrice(tax))
                $("input[data-type=unit-price]").val(formatCurrencyPrice(unitPrice))
            }
            console.log(netSale);
        })

        $("input[name=tax-include]").change(function () {
            const regex = /[,]/g;
            let isTaxInclude = $(this).val()
            let qty = $("input[data-type=qty]").val() || 0;
            let price = $("input[name=buy-price]").val();
            let buyPrice =  price.replace(regex, '');
            let netSale = 0;
            let tax = 0;
            let unitPrice = 0

            if (isTaxInclude == 1) {
                netSale = parseInt(buyPrice/1.11);
                tax = buyPrice - netSale;
                unitPrice = parseInt(netSale/qty) || 0;
                /* set to input value placeholder */
                $("input[data-type=net-sales]").val(formatCurrencyPrice(netSale))
                $("input[data-type=tax]").val(formatCurrencyPrice(tax))
                $("input[data-type=unit-price]").val(formatCurrencyPrice(unitPrice))
            } else {
                netSale = parseInt(buyPrice);
                unitPrice = parseInt(netSale/qty) || 0;
                /* set to input value placeholder */
                $("input[data-type=net-sales]").val(formatCurrencyPrice(netSale))
                $("input[data-type=tax]").val(formatCurrencyPrice(tax))
                $("input[data-type=unit-price]").val(formatCurrencyPrice(unitPrice))
            }
        })

        $("input[data-type=qty]").on('keyup', function () {
            const regex = /[,]/g;
            let qty = $(this).val();
            let netSalesRaw = $("input[data-type=net-sales]").val();
            let netSale = netSalesRaw.replace(regex, '').split('.')[0];
            let unitPrice = parseInt(netSale/qty) || 0;
            $("input[data-type=unit-price]").val(formatCurrencyPrice(unitPrice))
        })

        function formatNumberPrice(n) {
            // format number 1000000 to 1,234,567
            return n.toString().replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
        }

        function formatCurrencyPrice(input) {
            // appends $ to value, validates decimal side
            // and puts cursor back in right position.

            // get input value
            var input_val = input;

            // don't validate empty input
            if (input_val === "") { return; }

            input_val = formatNumberPrice(input_val);
            input_val = input_val;

            // send updated string to input
            return input_val;
        }




    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/sistem-pencatatan/resources/views/advance_receives/advance_receive_add.blade.php ENDPATH**/ ?>