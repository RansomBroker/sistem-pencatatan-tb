<?php $__env->startSection('title', 'Tambah Category Baru'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        
        <div class="mb-3">
            <h2 class="h2 d-inline align-middle fw-bold">Tambah Category Baru</h2>
        </div>

        
        <div class="card card-body">
            <form method="POST" action="<?php echo e(URL::to('category/category-add/add')); ?>">
                
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="mb-3 col-12 col-lg-12">
                        <label class="form-label">Name <sup class="text-danger">(Required)</sup></label>
                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ketikan nama " name="name" value="<?php echo e(old('name')); ?>"/>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 col-12 col-lg-12 row">
                        <button type="submit" class="btn btn-secondary col-12 col-lg-12 mb-3">Tambah Category Baru</button>
                        <button type="reset" class="btn btn-danger col-lg-12 col-12">Clear</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/sistem-pencatatan/resources/views/categories/category_add.blade.php ENDPATH**/ ?>