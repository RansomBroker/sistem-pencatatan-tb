
<script src="<?php echo e(asset('public/assets/js/other/jquery-3.6.3.min.js')); ?>"></script>


<script src="<?php echo e(asset('public/assets/js/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/datatables/dataTables.bootstrap5.min.js')); ?>"></script>


<script src="<?php echo e(asset('public/assets/js/admin/app.js')); ?>"></script>

<?php /**PATH /var/www/resources/views/includes/js.blade.php ENDPATH**/ ?>