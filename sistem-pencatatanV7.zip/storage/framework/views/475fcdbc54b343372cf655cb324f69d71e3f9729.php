
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap/bootstrap.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/datatables/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/datatables/dataTables.bootstrap5.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/boxicon/boxicons.min.css')); ?>">


<link href="<?php echo e(asset('public/assets/css/admin/app.css')); ?>" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link rel="shortcut icon" href="<?php echo e(asset('public/assets/img/icons/icon-48x48.png')); ?>" />
<?php /**PATH /var/www/resources/views/includes/css.blade.php ENDPATH**/ ?>