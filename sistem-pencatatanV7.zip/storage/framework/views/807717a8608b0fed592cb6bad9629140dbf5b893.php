
<script src="<?php echo e(asset('public/assets/js/other/jquery-3.6.3.min.js')); ?>"></script>


<script src="<?php echo e(asset('public/assets/js/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/datatables/dataTables.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/datatables/dataTables.checkboxes.min.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/js/admin/app.js')); ?>"></script>


<script src="<?php echo e(asset('public/assets/js/other/currency.js')); ?>"></script>


<script src="<?php echo e(asset('public/assets/js/sweetalert/sweetalert2.all.min.js')); ?>"></script>
<?php /**PATH /var/www/sistem-pencatatan/resources/views/includes/js.blade.php ENDPATH**/ ?>