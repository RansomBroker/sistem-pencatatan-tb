<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar ps-2">
        <a class="sidebar-brand" href="<?php echo e(URL::to('')); ?>">
            <span class="align-middle">Sistem Pencatatan</span>
        </a>

        <ul class="sidebar-nav">

            <li class="sidebar-item  <?php echo e(Route::current()->uri == '/' ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(URL::to('')); ?>">
                    <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
                </a>
            </li>

            <li class="sidebar-header">
                MASTER DATA
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="<?php echo e(URL::to('branch')); ?>">
                    <i class='bx bx-git-branch'></i>Branch</span>
                </a>
            </li>

        </ul>
    </div>
</nav>
<?php /**PATH /var/www/resources/views/includes/sidebar.blade.php ENDPATH**/ ?>