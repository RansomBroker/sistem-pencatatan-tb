<?php $__env->startSection('title', 'Category'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        
        <?php echo csrf_field(); ?>

        
        <div class="mb-3">
            <h2 class="h2 d-inline align-middle fw-bold">Category</h2>
        </div>

        
        <div class="card card-body row d-flex flex-column flex-wrap">

            <?php if($message = Session::get('message')): ?>
                <?php if($status = Session::get('status')): ?>
                    <div class="alert alert-<?php echo e($status); ?> alert-dismissible fade show" role="alert">
                        <?php echo e($message); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <a href="<?php echo e(URL::to('category/category-add')); ?>" class="col-12 col-lg-3 btn btn-secondary mb-3"> <i class='bx bx-plus'></i> Add New Categoryr</a>
            
            <div class="card card-body shadow-lg">
                <h3 class="d-inline align-middle"> Cari Category</h3>
                <h5 class="d-inline align-middle"> Filter Berdasarkan:</h5>
                <form class="mb-3" id="filter-form">
                    <div class="row g-2">
                        <div class="col-lg-6 col-12">
                            <label class="form-label">Nama Category</label>
                            <input class="form-control" name="name" placeholder="Ketikan Nama customer">
                        </div>
                        <div class="col-lg-6 col-12 row mt-3">
                            <button type="submit" class="btn btn-info btn-submit col-lg-2 col-12 me-1 align-self-end"><i class='bx bx-search' ></i> Cari</button>
                            <button type="reset" class="btn btn-danger btn-reset col-lg-3 col-12 align-self-end"><i class='bx bx-reset'></i> Reset Filter</button>
                        </div>
                    </div>
                </form>
            </div>

            
            <div class="card card-body shadow-lg">
                <h3 class="d-inline align-middle"> Data Category </h3>
                <div class="table-responsive">
                    <table class="table table-striped table-hover w-100 text-nowrap" id="category-table">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script>
        $(document).ready(function () {
                /* initiate table */
                let categoryTable = $("#category-table").DataTable({
                    bProcessing: true,
                    bServerSide: true,
                    ajax: {
                        url: "<?php echo e(URL::to('category/data-get')); ?>",
                        headers: {'X-CSRF-TOKEN': $('[name=_token]').val()},
                        type: 'POST',
                    },
                    language: {
                        processing: `<div class="spinner-border text-secondary" role="status">
                        <span class="visually-hidden">Loading...</span>
                        </div>`,
                    },
                    columns: [
                        {
                            sortable: false,
                            "render": function(data, type, full, meat) {
                             return ``
                            }
                        },
                        {"data": "name"},
                        {
                            sortable: false,
                            "render": function(data, type, full, meat) {
                                return `<a href="<?php echo e(URL::to('category/category-edit')); ?>/${full.id}" class="btn btn-success"><i class='bx bxs-edit'></i> Edit</a>  <button class="btn btn-danger"><i class='bx bxs-trash=alt'></i> Delete</button>`
                            }
                        }
                    ]
                })

                $("#category-table_filter").hide()

                categoryTable.on( 'draw.dt', function () {
                    var PageInfo = $('#category-table').DataTable().page.info();
                    categoryTable.column(0, { page: 'current' }).nodes().each( function (cell, i) {
                        cell.innerHTML = i + 1 + PageInfo.start;
                    } );
                });

                /* filter data */
                $('.btn-submit').on('click', function (e) {
                    e.preventDefault()
                    categoryTable.columns().search('').draw();
                    let nameFilter = $('[name=name]').val();

                    if (nameFilter.length > 0 ) {
                        categoryTable.columns(1).search(nameFilter).draw();
                    }
                })

                $('.btn-reset').on('click', function (e) {
                    e.preventDefault();
                    $("#filter-form")[0].reset();
                    categoryTable.columns().search('').clear().draw();
                })

            }
        )
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/sistem-pencatatan/resources/views/categories/category.blade.php ENDPATH**/ ?>