<?php $__env->startSection('title', 'Branch'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        
        <?php echo csrf_field(); ?>

        
        <div class="mb-3">
            <h2 class="h2 d-inline align-middle fw-bold">Branch</h2>
        </div>

        
        <div class="card card-body row d-flex flex-column flex-wrap">

            <?php if($message = Session::get('message')): ?>
                <?php if($status = Session::get('status')): ?>
                    <div class="alert alert-<?php echo e($status); ?> alert-dismissible fade show" role="alert">
                        <?php echo e($message); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <a href="<?php echo e(URL::to('branch/branch-add')); ?>" class="col-12 col-lg-2 btn btn-secondary mb-3"> <i class='bx bx-plus'></i> Add New Branch</a>
            
            <div class="card card-body shadow-lg">
                <h3 class="d-inline align-middle"> Cari Branch</h3>
                <h5 class="d-inline align-middle"> Filter Berdasarkan:</h5>
                <form class="mb-3">
                    <div class="row g-1">
                        <div class="col-lg-2 col-6">
                            <label class="form-label">Nama</label>
                            <input class="form-control" name="name" placeholder="Ketikan Nama Branch">
                        </div>
                        <div class="col-lg-2 col-6">
                            <label class="form-label">Branch</label>
                            <input class="form-control" name="branch" placeholder="Ketikan Branch">
                        </div>
                        <div class="col-lg-2 col-6">
                            <label class="form-label">Address</label>
                            <input class="form-control" name="address" placeholder="Ketikan Alamat">
                        </div>
                        <div class="col-lg-2 col-6">
                            <label class="form-label">No. Telp</label>
                            <input class="form-control" name="tel" placeholder="Ketikan Alamat">
                        </div>
                        <div class="col-lg-2 col-6">
                            <label class="form-label">NPWP</label>
                            <input class="form-control" name="npwp" placeholder="Ketikan NPWP">
                        </div>
                        <div class="col-lg-2 col-6">
                            <label class="form-label">Company</label>
                            <input class="form-control" name="company" placeholder="Ketikan Company">
                        </div>
                        <button type="submit" class="btn btn-info btn-submit col-lg-2 col-12 me-1"><i class='bx bx-search' ></i> Cari</button>
                        <button type="submit" class="btn btn-danger btn-reset col-lg-2 col-12"><i class='bx bx-reset'></i> Reset Filter</button>
                    </div>
                </form>
            </div>

            
            <div class="card card-body shadow-lg">
                <h3 class="d-inline align-middle"> Data Branch </h3>
                <div class="table-responsive">
                    <table class="table table-striped table-hover w-100" id="branch-table">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Branch</th>
                            <th>Address</th>
                            <th>No.Telp</th>
                            <th>NPWP</th>
                            <th>Company</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>Name</th>
                            <th>Branch</th>
                            <th>Address</th>
                            <th>No.Telp</th>
                            <th>NPWP</th>
                            <th>Company</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script>
        $(document).ready(function () {
                /* initiate table */
                let branchTable = $("#branch-table").DataTable({
                    bProcessing: true,
                    bServerSide: true,
                    searchable: false,
                    ajax: {
                        url: "<?php echo e(URL::to('branch/data-get')); ?>",
                        headers: {'X-CSRF-TOKEN': $('[name=_token]').val()},
                        type: 'POST',
                    },
                    language: {
                        processing: `<div class="spinner-border text-secondary" role="status">
                        <span class="visually-hidden">Loading...</span>
                        </div>`,
                    },
                    columns: [
                        {"data": "name"},
                        {"data": "branch"},
                        {"data": "address"},
                        {"data": "telephone"},
                        {"data": "npwp"},
                        {"data": "company"},
                        {
                            sortable: false,
                            "render": function(data, type, full, meat) {
                                return `<a href="<?php echo e(URL::to('branch/branch-edit/')); ?>/${full.id}" class="btn btn-success"><i class='bx bxs-edit'></i> Edit</a>  <button class="btn btn-danger"><i class='bx bxs-trash=alt'></i> Delete</button>`
                            }
                        }
                    ]
                })
                /* filter data */
                $('.btn-submit').on('click', function (e) {
                    e.preventDefault()
                    branchTable.columns().search('').draw();
                    let nameFilter = $("[name=name]").val();
                    let branchFilter = $("[name=branch]").val();
                    let addressFilter = $("[name=address]").val();
                    let telephoneFilter = $("[name=tel]").val();
                    let npwpFilter = $("[name=npwp]").val();
                    let companyFilter = $("[name=company]").val();


                    if (nameFilter.length > 0 ) {
                        branchTable.columns(0).search(nameFilter).draw()
                    }
                    if (branchFilter.length > 0 ) {
                        branchTable.columns(1).search(branchFilter).draw()
                    }
                    if (addressFilter.length > 0) {
                        branchTable.columns(2).search(addressFilter).draw()
                    }
                    if (telephoneFilter.length > 0 ) {
                        branchTable.columns(3).search(telephoneFilter).draw()
                    }
                    if (npwpFilter.length > 0) {
                        branchTable.columns(4).search(npwpFilter).draw()
                    }
                    if (companyFilter.length > 0) {
                        branchTable.columns(5).search(companyFilter).draw()
                    }
                })
                $('.btn-reset').on('click', function (e) {
                    e.preventDefault();
                    $("[name=name]").val('');
                    $("[name=branch]").val('');
                    $("[name=address]").val('');
                    $("[name=tel]").val('');
                    $("[name=npwp]").val('');
                    $("[name=company]").val('');
                    branchTable.columns().search('').clear().draw();
                })
            }
        )
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/sistem-pencatatan/resources/views/branch/branch.blade.php ENDPATH**/ ?>