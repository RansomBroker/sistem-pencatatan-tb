<?php $__env->startSection('title', 'Edit Consumption'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        
        <div class="mb-3">
            <h2 class="h2 d-inline align-middle fw-bold">Edit Consumption</h2>
        </div>

        
        <div class="card card-body">
            <form method="POST" action="<?php echo e(URL::to('consumption/consumption-edit/edit')); ?>">
                
                <?php echo csrf_field(); ?>
                <div class="row">
                    <input type="hidden" name="advance-receive-id" value="<?php echo e($advanceReceive->id); ?>">
                    <div class="mb-3 col-lg-12 col-12">
                        <label class="form-label">Cabang Penjualan</label>
                        <input type="hidden" name="branch" value="<?php echo e($advanceReceive->branch_id); ?>">
                        <select class="form-select" name="branch" disabled>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->id); ?>" <?php if($branch->id == $advanceReceive->branch_id): ?> selected <?php endif; ?> ><?php echo e($branch->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3 col-lg-12 col-12">
                        <label class="form-label">Tanggal Penjualan</label>
                        <input type="date" class="form-control" name="buy-date" value="<?php echo e($advanceReceive->buy_date); ?>" readonly>
                    </div>
                    <div class="mb-3 col-lg-12 col-12">
                        <label class="form-label">Expired</label>
                        <input type="date" class="form-control" name="expired-date" value="<?php echo e($advanceReceive->expired_date); ?>" readonly>
                    </div>
                    <div class="mb-3 col-lg-12 col-12">
                        <label class="form-label">ID Customer</label>
                        <input name="customer-id" class="form-control" value="<?php echo e($advanceReceive->customers[0]->customer_id); ?>" readonly>
                    </div>
                    <div class="mb-3 col-lg-12 col-12">
                        <label class="form-label">Nama Customer</label>
                        <input name="customer-name" class="form-control" value="<?php echo e($advanceReceive->customers[0]->name); ?>" readonly>
                    </div>
                    <div class="mb-3 col-lg-12 col-12">
                        <label class="form-label">Tipe</label>
                        <input name="type" class="form-control" value="<?php echo e(ucfirst(strtolower($advanceReceive->type))); ?>" readonly>
                    </div>
                    <div class="mb-3 col-lg-12 col-12">
                        <label class="form-label">QTY Produk</label>
                        <input name="qty" class="form-control" value="<?php echo e($advanceReceive->qty); ?>" readonly>
                    </div>
                    <div class="mb-3 col-lg-12 col-12">
                        <label class="form-label">Produk</label>
                        <input name="product" class="form-control" value="<?php echo e($advanceReceive->products[0]->name); ?>" readonly>
                    </div>
                    <div class="mb-3 col-lg-12 col-12">
                        <label class="form-label">Kategori Produk</label>
                        <input name="category" class="form-control" value="<?php echo e($advanceReceive->products[0]->categories[0]->name); ?>" readonly>
                    </div>
                    
                    <?php if(count($advanceReceive->consumptions[0]->history) > 0): ?>
                        <?php $__currentLoopData = $advanceReceive->consumptions[0]->history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $consumption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" value="<?php echo e($consumption->id); ?>" name="consumption-id[]">
                            <div class="mb-3 col-lg-12 col-12">
                                <label class="form-label">Tanggal Consumption Advance Receive Ke-<?php echo e($key+1); ?></label>
                                <input type="date" name="consumption-date[]" class="form-control" value="<?php echo e($consumption->consumption_date); ?>">
                            </div>
                            <div class="mb-3 col-lg-12 col-12">
                                <label class="form-label">Tempat Consumption Advance Receive Ke-<?php echo e($key+1); ?></label>
                                <select class="form-select" name="consumption-branch[]">
                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($branch->id); ?>" <?php if($branch->id == $consumption->branch_id): ?> selected <?php endif; ?> ><?php echo e($branch->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3 col-lg-12 col-12">
                                <button class="btn-delete btn btn-danger w-100" data-consumption="<?php echo e($advanceReceive->id.'||'.$consumption->used_count.'||'.$consumption->id); ?>">Hapus Consumption Ke-<?php echo e($key+1); ?></button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="alert alert-secondary mb-3 col-lg-12 col-12">
                            <p class="text-center m-0">Tidak Ada Consumption</p>
                        </div>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-secondary col-12 col-lg-12 mb-3">Edit Consumption</button>
                    <a href="<?php echo e(URL::to('consumption')); ?>" class="btn btn-danger col-12 col-lg-12"> Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script>
        $(".btn-delete").on("click", function(e) {
            e.preventDefault();
            let consumptionData = $(this).attr('data-consumption').split("||");
            let advanceReceiveID = consumptionData[0];
            let consumptionUsedCount = consumptionData[1];
            let consumptionID = consumptionData[2];

            $.ajax({
                url: "<?php echo e(URL::to('consumption/consumption-delete')); ?>",
                method: "POST",
                headers: {'X-CSRF-TOKEN': $('[name=_token]').val()},
                data: {
                    'advance-receive-id' : advanceReceiveID,
                    'consumption-id' : consumptionID,
                    'consumption-used-count' : consumptionUsedCount
                },
                beforeSend: function () {
                    Swal.fire({
                        html: `
                                            <div class="d-flex justify-content-center fs-4 ">
                                                  <span class="spinner-border spinner-border-sm text-primary fs-4" role="status" aria-hidden="true"></span>
                                                    Loading...
                                            </div>
                                        `,
                        showConfirmButton: false,
                        allowOutsideClick: false,
                        allowEscapeKey: false
                    })
                },
                success: function (response) {
                    if (response.status === "failed"){
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal Menghapus Consumption ke-'+consumptionUsedCount,
                            text: response.message,
                            showConfirmButton: false,
                            allowOutsideClick: false,
                            allowEscapeKey: false
                        })
                        setTimeout(function () {
                            window.location.reload();
                        }, 1250)
                    }
                    if (response.status === "success"){
                        Swal.fire({
                            icon: 'success',
                            title: response.message,
                            text: response.message,
                            showConfirmButton: false,
                            allowOutsideClick: false,
                            allowEscapeKey: false
                        })
                        setTimeout(function () {
                            window.location.reload();
                        }, 1250)
                    }
                }
            })

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/sistem-pencatatan/resources/views/consumptions/consumption_edit.blade.php ENDPATH**/ ?>